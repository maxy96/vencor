<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TiposViviendas extends Model
{
    protected $table = 'tipos_viviendas';
}
