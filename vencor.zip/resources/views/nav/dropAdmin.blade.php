<a class="dropdown-item" href="{{route('formulario.nuevoProducto')}}">
   Agregar producto
</a>
<a class="dropdown-item" href="{{route('gestionar.usuarios')}}">
   Gestionar usuarios
</a>
<a class="dropdown-item" href="{{route('gestionar.productos')}}">
   Gestionar productos
</a>
<a class="dropdown-item" href="#">
   Gestionar proveedor
</a>
<a class="dropdown-item" href="{{route('gestionar.pedidos')}}">
   Gestionar pedidos
</a>
                                    