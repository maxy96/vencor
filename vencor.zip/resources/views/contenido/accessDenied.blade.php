@extends('layouts.app')
@section('title', 'Acceso denegado')
@section('content')
<div class="container my-4">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">
				<div class="card-body">
					<h1 class="text-center">Acceso denegado</h1>
					<h2 class="text-center">No tienes permiso para acceder a esta pagina</h2>
				</div>
			</div>
	

		</div>
	</div>
</div>
@endsection