@extends('layouts.app')
@section('title', 'Agregar promocion')
@section('content')
	<div id="app">
		<agregar-promocion></agregar-promocion>
	</div>
@endsection