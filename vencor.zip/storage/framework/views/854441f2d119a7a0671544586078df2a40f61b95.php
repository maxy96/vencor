
<?php $__env->startSection('title', 'Gestionar Productos'); ?>

<?php $__env->startSection('content'); ?>
	<div id="app" class="container my-4">
		{{productos}}
		<h1 class="text-center my-4">Gestionar Productos</h1>
		<div class="my-4">
			<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#formulario" data-whatever="">Agregar Productos</button>
			<?php echo $__env->make('admin.modalFormAgregarProducto', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
		<div class="justify-content-center shadow bg-white my-4">
			
			<div class="table-responsive">
				<table class="table table-striped ">
				<thead class="thead-dark">
					<tr>
						<th scope="col">ID Producto</th>
						<th scope="col">Imagen</th>
						<th scope="col">Producto</th>
						<th scope="col">Marca</th>
						<th scope="col">Precio</th>
						<th scope="col">Stock</th>
						<th scope="col">Accion</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td scope="row"><?php echo e($producto->id_producto); ?></td>
						<td><img src="<?php echo e(asset("image/$producto->p_imagen")); ?>" alt="" style="width: 100px;height: 100px;"></td>
						<td><?php echo e($producto->nombre); ?></td>
						<td><?php echo e($producto->marca); ?></td>
						<td><?php echo e($producto->precio); ?></td>
						<td><?php echo e($producto->stock); ?></td>
						<td><a class="btn btn-success" href="#">Modificar</a></td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
			</div>		
		</div>
		
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	
	<script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.19.2/axios.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/vue/1.0.18/vue.js"></script>
	<script src="<?php echo e(asset('js/agregarProductos.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vencor\resources\views/admin/gestionarProductos.blade.php ENDPATH**/ ?>