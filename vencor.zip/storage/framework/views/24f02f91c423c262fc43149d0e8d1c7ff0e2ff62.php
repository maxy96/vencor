<?php if(App\Models\OrdenPedidos::where('tipoPedido_id', '=', 1)->count() >0): ?>
<?php $__currentLoopData = App\Models\OrdenPedidos::where('tipoPedido_id', '=', 1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item border border-danger my-1">
            <div class="row justify-content-center">
                <div class="col-md-3">
                    <?php echo e($item->user()->first()->nombre); ?>

                    <?php echo e($item->user()->first()->apellido); ?>

                </div>
                <div class="col-md-9">
                        <?php echo e(__('Solicita un nuevo pedido')); ?>

                </div>
                <hr>
            </div>
        </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="row" style="margin: 0px;">
        <a class="btn btn-primary btn-sm btn-block" href="#">
            Ver Pedidos <i class="fa fa-eye"></i>
        </a>
    </div>
<?php else: ?>
        <li class="list-group-item">No se ha solicitado pedidos</li>
<?php endif; ?><?php /**PATH C:\laragon\www\vencor\resources\views/nav/dropNotificationAdmin.blade.php ENDPATH**/ ?>