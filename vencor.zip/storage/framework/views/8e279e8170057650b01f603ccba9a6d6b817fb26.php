
<?php $__env->startSection('title', 'Detalle de la orden'); ?>
<?php $__env->startSection('content'); ?>
	<div class="container-fluid" style="background-color: #ffffffaa;">
		<div class="row justify-content-center">
			<div class="col-md-10 py-2">
				
				<h1 class="text-center"><u>Factura</u></h1>
				<div class="py-2 px-4">
					<h5><strong>Cliente:</strong><i> <?php echo e(ucfirst($user->nombre).' '.ucfirst($user->apellido)); ?></i></h5>
					<h5><strong>DNI:</strong><i> <?php echo e($user->dni); ?></i></h5>
					<h5><strong>Fecha Orden:</strong><i> <?php echo e(now()->format('d/m/Y')); ?></i></h5>
				</div>
				<div class="border-dashed border-secondary my-2"></div>
				<h3 class="text-center my-2">Detalle del pedido</h3>
				<table class="table table-sm table-borderless">
				  <thead>
				    <tr>
				      <th scope="col">Cod-Producto</th>
				      <th scope="col">Producto</th>
				      <th scope="col">Precio</th>
				      <th scope="col">Cantidad</th>
					  <th scope="col">Subtotal</th>
				    </tr>
				  </thead>
				  <tbody>				  	
					<?php $__currentLoopData = $carrito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<th scope="row"><?php echo e($producto->id); ?></th>
						<td><?php echo e($producto->name); ?></td>
						<td>$<?php echo e($producto->price); ?></td>
						<td><?php echo e($producto->quantity); ?></td>
						<td>$<?php echo e(\Cart::get($producto->id)->getPriceSum()); ?></td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td></td>
						<td></td>
						<td></td>
						<th>Cantidad total:</th>
						<th><?php echo e(\Cart::getTotalQuantity()); ?></th>
					</tr>
					<tr>
						<td></td>
						<td></td>
						<td></td>
						<th>Precio total:</th>
						<th>$<?php echo e(\Cart::getTotal()); ?></th>
					</tr>
				  </tbody>
				</table>
				<div class="border-dashed border-secondary"></div>
				<div class="justify-content-center my-4">
					<h2 class="text-center">Codigo de Orden</h2>
					<h4 class="text-center">123456790</h4>
					<h6 class="text-center"><strong>Indique este codigo al momento de recibir el producto</strong></h6>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.pdf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vencor\resources\views/contenido/ordenFactura.blade.php ENDPATH**/ ?>