
<?php $__env->startSection('title', 'Agregar Contacto'); ?>
<?php $__env->startSection('content'); ?>
	<div class="container my-4">
		<div class="row justify-content-center">
			<div class="col-md-8">
				<?php if(session()->has('alert_msg')): ?>
	            <div class="alert alert-danger alert-dismissible fade show" role="alert">
	                <?php echo e(session()->get('alert_msg')); ?>

	                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
	                    <span aria-hidden="true">×</span>
	                </button>
	            </div>
	       	 	<?php endif; ?>
				<div class="card shadow">
					<div class="card-header bg-orange text-white"><?php echo e(__('Agregar datos de Contacto')); ?></div>
					<div class="card-body">
						<form method="POST" action="<?php echo e(route('guardar.contacto')); ?>">
							<?php echo csrf_field(); ?>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group row">
	                            		<label for="nombre" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre')); ?></label>
			                            <div class="col-md-8">
			                                <input id="nombre" type="text" class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nombre" value="<?php echo e(old('nombre')); ?>" required autofocus>

			                                <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <span class="invalid-feedback" role="alert">
			                                        <strong><?php echo e($message); ?></strong>
			                                    </span>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            </div>
	                        		</div> 
								</div>
								<div class="col-md-6">
									<div class="form-group row">
	                            		<label for="apellido" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Apellido')); ?></label>
	                            		<div class="col-md-8">
	                               			 <input id="apellido" type="text" class="form-control <?php $__errorArgs = ['apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="apellido" value="<?php echo e(old('apellido')); ?>" required autofocus>
			                                <?php $__errorArgs = ['apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <span class="invalid-feedback" role="alert">
			                                        <strong><?php echo e($message); ?></strong>
			                                    </span>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	                            		</div>
	                        		</div> 
								</div>
								<div class="col-md-6">
									 <div class="form-group row">
			                            <label for="dni" class="col-md-4 col-form-label text-md-right"><?php echo e(__('DNI')); ?></label>

			                            <div class="col-md-8">
			                                <input id="dni" type="text" class="form-control <?php $__errorArgs = ['dni'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="dni" value="<?php echo e(old('dni')); ?>" required autofocus>

			                                <?php $__errorArgs = ['dni'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <span class="invalid-feedback" role="alert">
			                                        <strong><?php echo e($message); ?></strong>
			                                    </span>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            </div>
	                       			 </div> 
								</div>
								<div class="col-md-6">
									 <div class="form-group row">
			                            <label for="tipohogar" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Tipo de hogar')); ?></label>

			                            <div class="col-md-8">
			                                <select class="form-control" name="tipohogar" required>
			                                	<?php $__currentLoopData = $thogar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hogar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                                    	<option value="<?php echo e($hogar->id_tipoVivienda); ?>"><?php echo e($hogar->descripcion); ?></option>
			                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                                </select>

			                                <?php $__errorArgs = ['tipohogar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <span class="invalid-feedback" role="alert">
			                                        <strong><?php echo e($message); ?></strong>
			                                    </span>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            </div>
	                       			 </div> 
								</div>
								<div class="col-md-6">
									 <div class="form-group row">
			                            <label for="domicilio" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Domicilio')); ?></label>

			                            <div class="col-md-8">
			                                <input id="domicilio" type="text" class="form-control <?php $__errorArgs = ['domicilio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="domicilio" value="<?php echo e(old('domicilio')); ?>" required autofocus>

			                                <?php $__errorArgs = ['domicilio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <span class="invalid-feedback" role="alert">
			                                        <strong><?php echo e($message); ?></strong>
			                                    </span>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            </div>
	                       			 </div> 
								</div>
								<div class="col-md-6">
									<div class="form-group row">
			                            <label for="altura" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Altura')); ?></label>

			                            <div class="col-md-8">
			                                <input id="altura" type="text" class="form-control <?php $__errorArgs = ['altura'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="altura" value="<?php echo e(old('altura')); ?>" required placeholder="Ej: 01, 22, 333, 4444">

			                                <?php $__errorArgs = ['altura'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <span class="invalid-feedback" role="alert">
			                                        <strong><?php echo e($message); ?></strong>
			                                    </span>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            </div>
	                       		 	</div>
								</div>
								<div class="col-md-12">
									<div class="form-group row">
	                            		<label for="casa_descripcion" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Breve descripcion de la casa')); ?></label>
	                            		<div class="col-md-10">
			                                <textarea id="casa_descripcion" type="text" class="form-control <?php $__errorArgs = ['casa_descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="casa_descripcion" value="<?php echo e(old('casa_descripcion')); ?>" required autofocus placeholder="Color de casa o departamento, etc." style="resize: none;" rows="6"></textarea>

			                                <?php $__errorArgs = ['casa_descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <span class="invalid-feedback" role="alert">
			                                        <strong><?php echo e($message); ?></strong>
			                                    </span>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	                            		</div>
	                        		</div>
								</div>
							</div>
	                        <div class="form-group row mb-0">
	                            <div class="col-md-6 offset-md-4">
	                                <button type="submit" class="btn btn-primary">
	                                    <?php echo e(__('Agregar contacto')); ?>

	                                </button>
	                            </div>
                        	</div>  
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vencor\resources\views/contenido/agregarContacto.blade.php ENDPATH**/ ?>