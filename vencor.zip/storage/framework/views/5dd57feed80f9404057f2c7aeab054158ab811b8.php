<aside class="bg-dark" id="avisoCookies">
	Esta página utiliza cookies propias y de terceros con el fin de mejorar el servicio. Si continuas navegando, aceptas su uso. Puedes informarte sobre cómo cambiar la configuración de tu navegador u obtener más información sobre la ley de cookies <a href="#" rel="nofollow">siguiendo este enlace</a>.
	<button class="btn btn-primary" id="aceptarCookies">Aceptar</button>
</aside><?php /**PATH C:\laragon\www\vencor\resources\views/layouts/infoCookies.blade.php ENDPATH**/ ?>