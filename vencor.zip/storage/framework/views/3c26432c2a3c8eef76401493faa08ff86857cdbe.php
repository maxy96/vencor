<?php $__currentLoopData = App\Models\TiposProductos::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tproducto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a class="dropdown-item" href="<?php echo e(route('tipo.producto', $tproducto->slug)); ?>"> <?php echo e($tproducto->tp_descripcion); ?> </a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                   
<?php /**PATH C:\laragon\www\vencor\resources\views/nav/tipoProducto-drop.blade.php ENDPATH**/ ?>