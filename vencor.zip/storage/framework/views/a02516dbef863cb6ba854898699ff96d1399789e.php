
<?php $__env->startSection('title', 'Detalle de la orden'); ?>
<?php $__env->startSection('content'); ?>
	<div class="container-fluid" style="background-color: #ffffffaa;">
		<div class="row justify-content-center">
			<div class="col-md-10 py-2">
				
				<h1 class="text-center"><u>Factura</u></h1>
				<div class="py-2 px-4">
					<h5><strong>Cliente:</strong><i> <?php echo e(ucfirst($orden->user()->first()->nombre).' '.ucfirst($orden->user()->first()->apellido)); ?></i></h5>
					<h5><strong>DNI:</strong><i> <?php echo e($orden->user()->first()->dni); ?></i></h5>
					<h5><strong>Fecha Orden:</strong><i> <?php echo e($orden->fechaPedido); ?></i></h5>
				</div>
				<div class="border-dashed border-secondary my-2"></div>
				<h3 class="text-center my-2">Detalle del pedido</h3>
				<table class="table table-sm table-borderless">
				  <thead>
				    <tr>
				      <th scope="col">Cod-Producto</th>
				      <th scope="col">Producto</th>
				      <th scope="col">Precio</th>
				      <th scope="col">Cantidad</th>
					  <th scope="col">Subtotal</th>
				    </tr>
				  </thead>
				  <tbody>
				  	<?php echo e($cantidad = 0); ?>

				  	<?php echo e($precio = 0.00); ?>

				  	
					<?php $__currentLoopData = $orden->detallesPedidos()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<th scope="row"><?php echo e($producto->productos()->first()->id_producto); ?></th>
						<td><?php echo e($producto->productos()->first()->nombre); ?></td>
						<td>$<?php echo e($producto->productos()->first()->precio); ?></td>
						<td><?php echo e($producto->d_cantidad); ?></td>
						<td>$<?php echo e($producto->d_precio); ?></td>
						<?php echo e($cantidad += $producto->d_cantidad); ?>

						<?php echo e($precio += $producto->d_precio); ?>

					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td></td>
						<td></td>
						<td></td>
						<th>Cantidad total:</th>
						<th><?php echo e($cantidad); ?></th>
					</tr>
					<tr>
						<td></td>
						<td></td>
						<td></td>
						<th>Precio total:</th>
						<th>$<?php echo e($precio); ?></th>
					</tr>
				  </tbody>
				</table>
				<div class="border-dashed border-secondary"></div>
				<div class="justify-content-center my-4">
					<h2 class="text-center">Codigo de Orden</h2>
					<h4 class="text-center"><?php echo e($orden->cod_ordenPedido); ?></h4>
					<h6 class="text-center"><strong>Indique este codigo al momento de recibir el producto</strong></h6>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.pdf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vencor\resources\views/contenido/factura.blade.php ENDPATH**/ ?>