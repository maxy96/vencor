<a class="dropdown-item" href="<?php echo e(route('mis.pedidos')); ?>">
   Mis pedidos
</a>
                                    <?php /**PATH C:\laragon\www\vencor\resources\views/nav/dropCliente.blade.php ENDPATH**/ ?>