<footer class="bg-orange text-white border-top bm-0 mt-4 pb-2">
		<div class="justify-content-center my-4">
			<ul class="nav flex-column border-bottom">
				<li class="nav-item d-flex justify-content-center my-2">
	     			 <a class="link-footer" href="#">Terminos de condiciones y privacidad</a>
	    		</li>
	    		<li class="nav-item d-flex justify-content-center my-2">
	     			 <a class="link-footer" href="#">Politica de cookies</a>
	   			</li>
	   			<li class="nav-item d-flex justify-content-center my-2">
	      			<a class="link-footer" href="#">Sobre nosotros</a>
	    		</li>	
	   			<li class="nav-item d-flex justify-content-center my-2">
	      			<a class="link-footer" href="#">Sobre vencor</a>
	    		</li>
			</ul>
		</div>
	</div>
	<h4 class="text-center ">Copyright © vencor</h4>
</footer><?php /**PATH C:\laragon\www\vencor\resources\views/layouts/footer.blade.php ENDPATH**/ ?>