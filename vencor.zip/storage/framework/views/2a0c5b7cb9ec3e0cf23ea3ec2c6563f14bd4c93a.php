
<?php $__env->startSection('title', 'Agregar promocion'); ?>
<?php $__env->startSection('content'); ?>
	<div id="app">
		<agregar-promocion></agregar-promocion>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vencor\resources\views/admin/agregarPromocion.blade.php ENDPATH**/ ?>