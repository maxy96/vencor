
<?php $__env->startSection('title', 'Gestionar usuarios'); ?>
<?php $__env->startSection('content'); ?>
	<div class="container my-4">
		<h1 class="text-center">Gestionar usuarios</h1>
		<input type="search" class="form-control">
		<div class="table-responsive ">
			<table class="table table-hover bg-white shadow">
				<thead class="thead-dark">
					<tr>
						<th>ID</th>
					</tr>
				</thead>
			</table>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vencor\resources\views/admin/gestionarUsuarios.blade.php ENDPATH**/ ?>