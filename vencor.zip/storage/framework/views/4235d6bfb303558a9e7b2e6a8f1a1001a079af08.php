
<?php $__env->startSection('title', 'Nuevo Producto'); ?>
<?php $__env->startSection('content'); ?>
	<div class="container my-4">
		<div class="row justify-content-center">
	        <div class="col-md-8">
		        <?php if(session()->has('success_msg')): ?>
	            <div class="alert alert-success alert-dismissible fade show" role="alert">
	                <?php echo e(session()->get('success_msg')); ?>

	                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
	                    <span aria-hidden="true">×</span>
	                </button>
	            </div>
	       	 	<?php endif; ?>
	            <div class="card">
	                <div class="card-header"><?php echo e(__('Nuevo Producto')); ?> <?php echo $__env->make('contenido.nuevoTipoProducto', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> </div>
	                <div class="card-body">
	                    <form method="POST" action="<?php echo e(route('guardar.producto')); ?>" enctype="multipart/form-data">
	                        <?php echo csrf_field(); ?>

	                        <div class="form-group row">
	                            <label for="tipo" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Tipo producto')); ?></label>

	                            <div class="col-md-6">
	                            	<select name="tipoProducto" id="tipoProducto" class="form-control <?php $__errorArgs = ['tipoProducto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tipoProducto" value="<?php echo e(old('tipoproducto')); ?>" required>
	                            		<option value="">-- Seleccionar tipo de producto --</option>
	                            		<?php $__currentLoopData = App\Models\TiposProductos::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tproducto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    										<option value="<?php echo e($tproducto->id_tipoProducto); ?>"> <?php echo e($tproducto->tp_descripcion); ?> </a>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                            	</select>
	                                
	                                <?php $__errorArgs = ['tipoProducto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                                    <span class="invalid-feedback" role="alert">
	                                        <strong><?php echo e($message); ?></strong>
	                                    </span>
	                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	                            </div>
	                        </div>
	                        
	                        <div class="form-group row">
	                            <label for="nombre" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre producto')); ?></label>

	                            <div class="col-md-6">
	                                <input id="nombre" type="text" class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nombre" value="<?php echo e(old('nombre')); ?>" required autofocus>

	                                <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                                    <span class="invalid-feedback" role="alert">
	                                        <strong><?php echo e($message); ?></strong>
	                                    </span>
	                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	                            </div>
	                        </div>


	                        <div class="form-group row">
	                            <label for="marca" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Marca')); ?></label>

	                            <div class="col-md-6">
	                                <input id="marca" type="text" class="form-control <?php $__errorArgs = ['marca'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="marca" value="<?php echo e(old('marca')); ?>" required autofocus>

	                                <?php $__errorArgs = ['marca'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                                    <span class="invalid-feedback" role="alert">
	                                        <strong><?php echo e($message); ?></strong>
	                                    </span>
	                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	                            </div>
	                        </div>

	                        <div class="form-group row">
	                            <label for="stock" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Stock')); ?></label>

	                            <div class="col-md-6">
	                                <input id="stock" type="number" class="form-control <?php $__errorArgs = ['stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="stock" value="<?php echo e(old('stock')); ?>" required autofocus>

	                                <?php $__errorArgs = ['stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                                    <span class="invalid-feedback" role="alert">
	                                        <strong><?php echo e($message); ?></strong>
	                                    </span>
	                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	                            </div>
	                        </div>

	                        <div class="form-group row">
	                            <label for="precio" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Precio')); ?></label>

	                            <div class="col-md-6">
	                                <input id="precio" type="number" placeholder="0.00" step="0.01" class="form-control <?php $__errorArgs = ['precio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="precio" value="<?php echo e(old('precio')); ?>" required autofocus>

	                                <?php $__errorArgs = ['precio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                                    <span class="invalid-feedback" role="alert">
	                                        <strong><?php echo e($message); ?></strong>
	                                    </span>
	                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	                            </div>
	                        </div>

	                        <div class="form-group row">
	                            <label for="imagen" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Subir imagen')); ?></label>

	                            <div class="col-md-6">
	                                <input id="imagen" type="file" class=" <?php $__errorArgs = ['imagen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" accept="image/*" name="imagen" value="<?php echo e(old('imagen')); ?>" required autofocus>

	                                <?php $__errorArgs = ['imagen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                                    <span class="invalid-feedback" role="alert">
	                                        <strong><?php echo e($message); ?></strong>
	                                    </span>
	                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	                            </div>
	                        </div>

	                        <div class="form-group row mb-0">
	                            <div class="col-md-6 offset-md-4">
	                                <button type="submit" class="btn btn-primary">
	                                    <?php echo e(__('Agregar producto nuevo')); ?>

	                                </button>
	                            </div>
	                        </div>

	                    </form>
	                </div>
	            </div>
	        </div>
    	</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vencor\resources\views/contenido/nuevoProducto.blade.php ENDPATH**/ ?>