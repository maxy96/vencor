<nav class="navbar navbar-expand-md navbar-orange <?php if(Request::segment(1)<>null): ?> sticky-top bg-white shadow-sm <?php else: ?> fixed-top <?php endif; ?>" style="transition: 0.5s ease;">
     <div id="menu" class="container-fluid">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(asset('logo-vencor.png')); ?>" style="height: 2.5rem;" alt="vencor">
                </a>
                <button class="navbar-toggler bg-bluelight" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <i class="fa fa-bars text-white" style="font-size: 25px;"></i>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item mx-1 my-1">
                            <a class="nav-link" href="<?php echo e(route('productos')); ?>"><?php echo e(__('Productos')); ?> </a>
                        </li>
                        <li class="nav-item mx-1 my-1">
                            <a class="nav-link" href="<?php echo e(route('promo')); ?>"><?php echo e(__('Promocion')); ?> </a>
                        </li>
                        <li class="nav-item dropdown mx-1 my-1">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(__('Categorias')); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <?php echo $__env->make('nav.tipoProducto-drop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </li>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item mx-1 my-1">
                                <a class=" btn btn-primary" href="<?php echo e(route('login')); ?>"><i class="fa fa-sign-in"></i> <?php echo e(__('Iniciar sesion')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item mx-1 my-1">
                                    <a class=" btn btn-success" href="<?php echo e(route('register')); ?>"><i class="fa fa-user-o"></i> <?php echo e(__('Registrarse')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link-o mx-1 dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <i class="fa fa-user-circle-o" style="font-size: 21px;"></i> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                   <!--dropdown user -->
                                   <h6 class="dropdown-header"><?php echo e(Auth::User()->perfil()->first()->descripcion); ?></h6>
                                   <div class="dropdown-divider"></div>
                                   
                                   <?php if(Auth::user()->perfil_id == 1): ?>
                                        <?php echo $__env->make('nav.dropAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                   <?php else: ?>
                                        <?php echo $__env->make('nav.dropCliente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                
                                   <?php endif; ?>                                 
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Cerrar sesion')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                            <?php if(Auth::user()->perfil_id == 1): ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link-o mx-1 dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <span class="badge badge-pill badge-dark">
                                        <i class="fa fa-bell"></i> <?php echo e(App\Models\OrdenPedidos::where('tipoPedido_id', '=', 1)->count()); ?>

                                    </span>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown" style="width: 390px; padding: 0px; border-color: #9DA0A2">
                                    <ul class="list-group" style="margin: 20px;height: 400px; overflow-y: scroll;">
                                        <?php echo $__env->make('nav.dropNotificationAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </ul>
                                </div>
                            </li>
                            <?php endif; ?>

                            <li class="nav-item dropdown">
                                 <a id="navbarDropdown" class="nav-link-o mx-1 dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"style="color: black;">
                                    <span class="badge badge-pill badge-dark">
                                        <i class="fa fa-shopping-cart"></i> <?php echo e(\Cart::session(\Auth::user()->id_user)->getTotalQuantity()); ?>

                                    </span>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown" style="width: 450px; padding: 0px; border-color: #9DA0A2">
                                    <ul class="list-group" style="margin: 20px;">
                                        <?php echo $__env->make('nav.cart-drop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </ul>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
     </div>
</nav><?php /**PATH C:\laragon\www\vencor\resources\views/nav/nav.blade.php ENDPATH**/ ?>