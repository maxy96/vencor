
<?php $__env->startSection('title', 'Productos'); ?>
<?php $__env->startSection('content'); ?>
	<div class="container my-4">
		<div class="row">
			<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<article class="col-md-3 my-2 mx-2 ">
				<div class="card shadow" >
			  		<img class="card-img-top" src="<?php echo e(asset("image/$producto->p_imagen")); ?>" alt="Card image cap" style="height: 160px;">
			  		<h5 class="card-header"><?php echo e($producto->nombre); ?></h5>
			 	 	<div class="card-body">
			   			 <p class="card-text">Marca: <?php echo e($producto->marca); ?></p>
			   			 <p class="card-text">Stock: <?php echo e($producto->stock); ?></p>
			 		</div>
			 		<div class="card-footer ">
				    	<span class="card-link">$<?php echo e($producto->precio); ?></span>
	    				
	    				<?php if(auth()->guard()->check()): ?>
		    				<form action="<?php echo e(route('cart.store')); ?>" method="POST">
	               			 <?php echo e(csrf_field()); ?>

	                			<input type="hidden" value="<?php echo e($producto->id_producto); ?>" id="id" name="id">
	                			<input type="hidden" value="<?php echo e($producto->nombre); ?>" id="name" name="name" readonly="readonly">
	                			<input type="hidden" value="<?php echo e($producto->precio); ?>" id="price" name="price" readonly="readonly">
	                			<input type="hidden" value="<?php echo e($producto->p_imagen); ?>" id="img" name="img">
	                			<input type="hidden" value="<?php echo e($producto->slug); ?>" id="slug" name="slug">
	                			<input type="hidden" value="<?php echo e($producto->tipoProducto_id); ?>" id="tipo_id" name="tipo_id">
	                			<input type="hidden" value="1" id="quantity" name="quantity">
	               				<button class="btn btn-secondary btn-sm" class="tooltip-test" title="	add to cart">
	                   				<i class="fa fa-shopping-cart"></i>Agregar al Carrito
	                			</button>
	            			</form>
            			<?php endif; ?>
			  		</div>
				</div>		
			</article>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vencor\resources\views/contenido/productos.blade.php ENDPATH**/ ?>