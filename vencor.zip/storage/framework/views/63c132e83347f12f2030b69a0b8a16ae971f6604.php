<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\vencor\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>