
<?php $__env->startSection('title', 'Gestionar pedidos'); ?>
<?php $__env->startSection('content'); ?>
	<div class="container my-4">
		<h1 class="text-center">Gestionar pedidos</h1>
		<div class="justify-content-center bg-white shadow">
			<div class="table-responsive">
			<table class="table table-striped">
				<thead class="thead-dark">
					<tr>
						<th scope="col">ID orden</th>
						<th scope="col">Persona</th>
						<th scope="col">DNI</th>
						<th scope="col">Codigo</th>
						<th scope="col">Telefono</th>
						<th scope="col">Domicilio</th>
						<th scope="col">Total Productos</th>
						<th scope="col">Precio Total</th>
						<th scope="col">Estado</th>
						<th scope="col">Ver</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $ordenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td scope="row"><?php echo e($orden->id_ordenPedido); ?></td>
						<td><?php echo e($orden->user()->first()->nombre.' '. $orden->user()->first()->apellido); ?></td>
						<td><?php echo e($orden->user()->first()->dni); ?></td>
						<td><?php echo e($orden->cod_ordenPedido); ?></td>
						<?php $__currentLoopData = $orden->user()->first()->contactos()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contacto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<td><?php echo e($contacto->telefono); ?></td>
						<td><?php echo e($contacto->domicilio); ?></td>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<td><?php echo e($orden->totalPedidos()); ?></td>
						<td>$<?php echo e($orden->totalPrecio()); ?></td>
						<td><?php echo e($orden->tipoPedido_id == 1 ? "pendiente" : "recibido"); ?></td>
						<td><a class="btn btn-primary" href="#"><i class="fa fa-eye"></i></a></td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vencor\resources\views/admin/gestionarPedidos.blade.php ENDPATH**/ ?>