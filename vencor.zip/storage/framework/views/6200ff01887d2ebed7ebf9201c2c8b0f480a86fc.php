<a class="dropdown-item" href="<?php echo e(route('formulario.nuevoProducto')); ?>">
   Agregar producto
</a>
<a class="dropdown-item" href="<?php echo e(route('gestionar.usuarios')); ?>">
   Gestionar usuarios
</a>
<a class="dropdown-item" href="<?php echo e(route('gestionar.productos')); ?>">
   Gestionar productos
</a>
<a class="dropdown-item" href="<?php echo e(route('gestionar.pedidos')); ?>">
   Gestionar pedidos
</a>
                                    <?php /**PATH C:\laragon\www\vencor\resources\views/nav/dropAdmin.blade.php ENDPATH**/ ?>