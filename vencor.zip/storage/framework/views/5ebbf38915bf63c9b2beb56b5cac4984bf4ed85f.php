
<?php $__env->startSection('title', 'Compra finalizada'); ?>
<?php $__env->startSection('content'); ?>
	<div class="container my-4">
		<div class="row justify-content-center">
			<div class="col-md-10">
				<div class="card shadow bg-white">
					<div class="card-body justify-content-center text-center">
					<?php if(session()->has('codigo')): ?>
						<h1 class="text-primary">¡Gracias por su compra!</h1>
						<h3>Recuerde usar el siguiente codigo al momento de recibir sus productos</h3>
						
							<h4 class="text-orange"><?php echo e(session()->get('codigo')); ?></h4>
							<h5>Tambien puede descargar su factura</h5>
							<a href="<?php echo e(route('orden.factura', session()->get('codigo'))); ?>" class="btn btn-block btn-success">Factura</a>
					<?php else: ?>
						<h1 class="text-danger">Datos no encontrados</h1>
					<?php endif; ?>
					</div>					
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vencor\resources\views/contenido/compraFinalizada.blade.php ENDPATH**/ ?>